#include <avr/io.h>
#define CDS_VALUE 871
#define F_CPU 16000000UL
#include <util/delay.h>
#include <avr/interrupt.h>

#define ON 1
#define OFF 0

volatile int state = OFF;

#define DO 17
#define RE 43
#define MI 66
#define FA 77
#define SOL 97
#define LA 114
#define TI 117
#define UDO 137

const unsigned char melody[25]={DO, RE, MI, FA, SOL, LA, TI, UDO};
volatile int idx = 0;

void init_adc();
unsigned short read_adc();
int show_adc(unsigned short value);

char fnd_value[3] = {};

typedef unsigned char uc;
const uc digit[10] = { 0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x27, 0x7f, 0x6f };
const uc fnd_sel[4] = { 0x08,0x04,0x02,0x01 };
const uc dot = 0x80;

int arr[4];


ISR(TIMER0_OVF_vect){
	if(state == ON){
		PORTB = 0x00;
		state = OFF;
	}
	else{
		PORTB = 0x10;
		state = ON;
	}
	TCNT0 = melody[idx];
}

int main() {
DDRE = 0xdf;
	EICRB = 0x08;
	EIMSK = 0x20;
	SREG |= 1<<7;
	DDRB = 0x10;
	TCCR0 = 0x03;
	
	TCNT0 = 17;
	DDRC = 0xff;
	DDRG = 0x0f;
	unsigned short value;
	DDRA = 0xff;
	init_adc();
	
	sei();
	while (1) {
		for(int u = 0; u < 4; u++) {
			PORTC = arr[u];
			PORTG = fnd_sel[u];
			
			value = read_adc();
			show_adc(value);

			_delay_ms(2.5);
		}

		
		
	}
}

void init_adc() {
	ADMUX = 0x00;
	// 00000000
	// REFS(1:0) = "00" AREF(+5V) �������� ���
	// ADLAR = '0' ����Ʈ ������ ����
	// MUX(4:0) = "00000" ADC0 ���, �ܱ� �Է�
	ADCSRA = 0x87;
	// 10000111
	// ADEN = '1' ADC�� Enable
	// ADFR = '0' single conversion ���
	// ADPS(2:0) = "111" ���������Ϸ� 128����
}

unsigned short read_adc() {
	unsigned char adc_low, adc_high;
	unsigned short value;
	ADCSRA |= 0x40; // ADC start conversion, ADSC = '1'
	while ((ADCSRA & (0x10)) != 0x10); // ADC ��ȯ �Ϸ� �˻�
	adc_low = ADCL;
	adc_high = ADCH;
	value = (adc_high << 8) | adc_low;

	return value;
}

int show_adc(unsigned short value) {
	
	if (value < CDS_VALUE) {
		TIMSK = 0x01;
		PORTA = 0xff;
		int i, j, k, l, t, x;
   	 	int num[4];
   		for (i = 0; ; i++) {
      		if (i == 10)
         		i = 0;
	
			num[0] = digit[i];
			arr[0] = num[0];
      		for (j = 0; j < 10; j++) {
        		num[1] = digit[j] + dot;
				arr[1] = num[1];
         		for (k = 0; k < 10; k++) {
           			num[2] = digit[k];
					arr[2] = num[2];
           			for (l = 0; l < 10; l++) {
          			    num[3] = digit[l];
						arr[3] = num[3];
               
               			for(t = 0; t < 4; t++) {
                  			PORTC = num[t];
                 			PORTG = fnd_sel[t];
                  			_delay_ms(2.5);
						
							if(read_adc()>= CDS_VALUE){
								PORTA = 0x00;
								TIMSK = 0x00;
								idx = (idx +1) % 8;
								return num;
							}
               			}
            		}
         		}
      		}
   		}

	}
	
}
