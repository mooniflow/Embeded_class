#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#define ON 1
#define OFF 0

volatile int state = OFF;

#define DO 17
#define RE 43
#define MI 66
#define FA 77
#define SOL 97
#define LA 114
#define TI 117
#define UDO 137

int arr[8]={DO, RE, MI, FA, SOL, LA, TI, UDO};
volatile int idx = 0;



ISR(TIMER0_OVF_vect){
	if(state == ON){
		PORTB = 0x00;
		state = OFF;
	}
	else{
		PORTB = 0x10;
		state = ON;
	}
	TCNT0 = arr[idx];
}

ISR(INT5_vect){
	idx = (idx +1) % 8;
	_delay_ms(10);
}


int main(){


	DDRE = 0xdf;
	EICRB = 0x08;
	EIMSK = 0x20;
	SREG |= 1<<7;
		

	DDRB = 0x10;
	TCCR0 = 0x03;
	TIMSK = 0x01;
	TCNT0 = 17;
	sei();
	while(1);
}
