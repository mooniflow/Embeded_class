

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#define ON 1
#define OFF 0

volatile int state = OFF;

#define DO 17
#define RE 43
#define MI 66
#define FA 77
#define SOL 97
#define LA 114
#define TI 117
#define UDO 137

const unsigned char melody[25]={MI, RE, DO, RE, MI, MI, MI, RE, RE, RE, MI, SOL, SOL, MI, RE, DO, RE , MI, MI, MI, RE, RE, MI, RE, DO};
volatile int idx = 0;



ISR(TIMER0_OVF_vect){
	if(state == ON){
		PORTB = 0x00;
		state = OFF;
	}
	else{
		PORTB = 0x10;
		state = ON;
	}
	TCNT0 = melody[idx];
}




int main(){


	DDRE = 0xef;
	EICRB = 0x02;
	EIMSK = 0x10;
	SREG |= 1<<7;
		

	DDRB = 0x10;
	TCCR0 = 0x03;
	TIMSK = 0x01;
	TCNT0 = melody[idx];
	sei();
	while(1){
		idx = (idx +1) % 25;
		_delay_ms(15000);
	}
}
